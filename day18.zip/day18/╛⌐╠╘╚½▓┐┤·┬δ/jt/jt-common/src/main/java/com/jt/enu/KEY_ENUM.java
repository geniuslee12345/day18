package com.jt.enu;
//定义key的类型
public enum KEY_ENUM {
	AUTO,	//key自动生成 方法名+第一个参数
	EMPTY;	//使用自己的key
}
